close all; 
clc;

b = [-1, 1];
a = 1;
figure;
freqz(b, a); 
title("Ƶ����Ӧ");
