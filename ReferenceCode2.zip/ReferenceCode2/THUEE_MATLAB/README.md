# THUEE_MATLAB

> THUEE MATLAB小学期大作业

## image

图像处理大作业，详见[报告](image/大作业报告.pdf)

## speech

语音合成大作业，详见[报告](soeech/大作业报告.pdf)

## music

音乐合成大作业（本大作业未完成并已中止）
