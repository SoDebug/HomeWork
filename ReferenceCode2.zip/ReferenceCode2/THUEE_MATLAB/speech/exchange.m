filename='dream.wav';%这个声音文件在该程序根目录
[signal,fs] = audioread(filename);%读取wav文件，读完是去除了文件头的采样点，而且归一化了，是浮点数。
info=audioinfo(filename)%看这个文件的信息。
whos signal%显示name size bytes class 等等
%保存raw文件
fid=fopen('dream.pcm','wb');%存为raw，也就是pcm格式
fwrite(fid,'int16');%我这里是按照int16读取的，所以是int16.
%想看自己读完是什么格式，可以在调试的时候点开signal数组看。
%audiowrite('D:\lab1\10new.wav', x_speech,fs);%这是存成wav格式的
fclose(fid);